Guide
two way you can use animation duration
Must you have to writte duration number class in first position example: class"1000 anotherClass" class"anotherClass 1000" ( minimum"1" & maximum"3000" )
<div data-effectJs-duration="1000" ></div>


All Attribute
<div
data-aos="fade-up"
data-aos-offset="200"
data-aos-delay="50"
data-aos-duration="1000" or class="1000 anotherClass"
data-aos-easing="ease" >
</div>
Example

<div data-effectJs-duration="1500" data-effectJs="fade-in"></div>
<div class="1500 anotherClass" data-effectJs="fade-in"></div>
All Animation Name
fade
fade-up
fade-down
fade-left
fade-right
fade-up-right
fade-up-left
fade-down-right
fade-down-left
flip-up
flip-down
flip-left
flip-right
slide-up
slide-down
slide-left
slide-right
zoom-in
zoom-in-up
zoom-in-down
zoom-in-left
zoom-in-right
zoom-out
zoom-out-up
zoom-out-down
zoom-out-left
zoom-out-right